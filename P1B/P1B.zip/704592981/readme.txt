This project is to practice some basic operation to Mysql Server and the access from PHP to Mysql.
There are totally 15 constraints.I provided violating modification SQL in the violate.sql. 
My logic is described in the source file by necessary comments.

Thanks~